from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import generics, status
from User.models import CustomUser
from Project.models import Projects
from Client.models import Clients
from .serializers import ProjectSerializer, UserSerializer, ClientSerializer
# Create your views here.
class UserView(generics.ListCreateAPIView):
    queryset = CustomUser.objects.all()
    serializer_class = UserSerializer
    permission_classes = ()
    authentication_classes = ()
class ProjectsView(generics.ListCreateAPIView):
    queryset = Projects.objects.all()
    serializer_class = ProjectSerializer
    permission_classes = ()
    authentication_classes = ()
class ClientView(generics.ListCreateAPIView):
    queryset = Clients.objects.all()
    serializer_class = ClientSerializer
    permission_classes = ()
    authetication_classes = ()

