from rest_framework import serializers
from User.models import CustomUser
from Client.models import Clients
from Project.models import Projects

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = CustomUser
        fields = ['email','full_name', 'sex', 'password']
        extra_kwargs = {'password':{'write_only':True}}
    def create(self, validated_data):
        usr = CustomUser(email=validated_data.get('email'), full_name=validated_data.get('full_name'), sex=validated_data.get('sex'))
        usr.set_password(validated_data.get('password'))
        usr.save()
        return usr
class ProjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Projects
        fields = ['title', 'about', 'date', 'user']
    user = UserSerializer()
class ClientSerializer(serializers.ModelSerializer):
    class Meta:
        model = Clients
        fields = ['user', 'projects_list', 'active_project', 'done_projects']
    user = UserSerializer()
    active_project = ProjectSerializer()
    done_projects = ProjectSerializer()