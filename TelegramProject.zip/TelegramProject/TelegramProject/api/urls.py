from django.urls import path
from .views import *
urlpatterns = [
    path('users/', UserView.as_view(), name='usrs'),
    path('users/projects/', ProjectsView.as_view(), name='projects'),
    path('users/clients/', ClientView.as_view(), name='clients')
]